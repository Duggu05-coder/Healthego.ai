# AI Therapy Chatbot

A compassionate AI-powered therapeutic chatbot that provides emotional support through personalized remedies, song recommendations, jokes, and book suggestions based on detected emotions.

## Features

- **Emotion Detection**: Automatically detects emotions from user text using multiple AI approaches
- **Therapeutic Responses**: Provides specific remedies tailored to detected emotions
- **Entertainment Recommendations**: Suggests songs, jokes, and books based on emotional state
- **Special Happy Response**: Shows "You look alright! 😊" for positive emotions
- **Quick Help Buttons**: Instant support for anxiety, sadness, and anger
- **Session Management**: Tracks conversation history and emotional patterns
- **Real-time Emotion Tracking**: Visual indicators of current emotional state

## Installation

### Prerequisites
- Python 3.7 or higher
- Internet connection for AI responses

### Setup

1. Clone this repository:
```bash
git clone <repository-url>
cd ai-therapy-chatbot
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Get a free Gemini API key:
   - Visit [Google AI Studio](https://ai.google.dev)
   - Create an account and generate an API key

4. Set up environment variables:
```bash
export GEMINI_API_KEY="your_api_key_here"
```

Or create a `.env` file:
```
GEMINI_API_KEY=your_api_key_here
```

### Running the Application

```bash
streamlit run app.py
```

The application will open in your browser at `http://localhost:8501`

## Usage

1. **Start Chatting**: Type how you're feeling in the input box at the bottom
2. **Get Remedies**: Receive personalized therapeutic responses with:
   - Song recommendations with artist names
   - Appropriate jokes and humor
   - Book suggestions with titles and authors
   - Therapeutic activities and exercises
3. **Quick Help**: Use the emotion-specific buttons for immediate support
4. **Track Progress**: View your emotional patterns in the sidebar

## Emotion Responses

- **Happy/Joy**: "You look alright! 😊" + uplifting content
- **Sad/Depressed**: Comforting remedies and hopeful suggestions
- **Anxious/Worried**: Calming techniques and soothing recommendations
- **Angry/Frustrated**: Energy release activities and stress relief
- **Neutral**: Mood-boosting suggestions

## File Structure

```
ai-therapy-chatbot/
├── app.py                 # Main Streamlit application
├── therapeutic_ai.py      # AI response generation
├── emotion_detector.py    # Emotion detection system
├── remedy_generator.py    # Therapeutic remedy database
├── session_manager.py     # Conversation and session handling
├── voice_handler.py       # Voice input/output features
├── database.py           # Database models and management
├── requirements.txt      # Python dependencies
├── README.md            # This file
└── .streamlit/
    └── config.toml      # Streamlit configuration
```

## Configuration

### Streamlit Settings
The app includes optimized Streamlit configuration for better performance and user experience.

### API Configuration
- **Gemini API**: Required for AI responses and emotion analysis
- **Voice Features**: Optional - requires microphone access

## Database Support

The application supports PostgreSQL for persistent conversation storage:
- Conversation history
- Emotion tracking
- Session statistics
- User preferences

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Privacy & Ethics

- No personal data is stored without explicit consent
- All conversations are processed securely
- The chatbot is for emotional support, not medical diagnosis
- Users are encouraged to seek professional help for serious mental health concerns

## License

This project is open source and available under the MIT License.

## Support

For support, please open an issue on GitHub or contact the development team.

## Disclaimer

This AI therapy chatbot is designed for emotional support and wellness. It is not a replacement for professional mental health care. If you're experiencing severe mental health issues, please consult with a qualified healthcare provider.