# GitHub Deployment Guide

## Download Package

**File:** `ai_therapy_chatbot_github.zip`

This package contains the complete AI therapy chatbot optimized for GitHub hosting.

## GitHub Setup Instructions

### 1. Upload to GitHub
1. Create new repository on GitHub
2. Extract the ZIP file contents
3. Upload all files to your repository
4. Commit and push changes

### 2. Repository Structure
```
your-repo/
├── app.py                 # Main application
├── therapeutic_ai.py      # AI response system
├── emotion_detector.py    # Emotion detection
├── remedy_generator.py    # Therapeutic remedies
├── session_manager.py     # Session handling
├── voice_handler.py       # Voice features
├── database.py           # Database support
├── image_analyzer.py     # Image analysis
├── requirements.txt      # Dependencies
├── README.md            # Documentation
├── .gitignore           # Git ignore rules
└── .streamlit/
    └── config.toml      # Streamlit config
```

### 3. GitHub Pages Deployment
Since this is a Streamlit app, you'll need to use:
- **Streamlit Community Cloud** (recommended)
- **Heroku**
- **Railway**
- **Replit**

### 4. Streamlit Community Cloud Setup
1. Go to [share.streamlit.io](https://share.streamlit.io)
2. Connect your GitHub account
3. Select your repository
4. Set main file: `app.py`
5. Add environment variables:
   - `GEMINI_API_KEY`: Your Google AI Studio API key

### 5. Environment Variables
Required:
- `GEMINI_API_KEY`: Get from [ai.google.dev](https://ai.google.dev)

Optional:
- `DATABASE_URL`: PostgreSQL connection string

### 6. Features Included
- Text-based therapeutic chat
- Emotion detection and validation
- Song, joke, and book recommendations
- Quick help buttons for common emotions
- Session management and history
- Real-time emotion tracking
- Special happy emotion response: "You look alright!"

### 7. User Instructions
1. Visit your deployed app URL
2. Add Gemini API key in sidebar
3. Start chatting about feelings
4. Get personalized therapeutic responses
5. Use quick help buttons for immediate support

## Local Development

```bash
git clone your-repo-url
cd your-repo
pip install -r requirements.txt
export GEMINI_API_KEY="your_key_here"
streamlit run app.py
```

## Support
- The chatbot focuses purely on emotional support
- Provides specific remedies based on detected emotions
- Input area fixed at bottom, messages display above
- No image/camera features - text-only interface

This package is ready for immediate deployment on any Streamlit-compatible hosting platform.